/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BattleMiddleEarth;

/**
 *
 * @author Arif
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


public class weapon extends GameObject{
		private int attackDamage;
		private int ammoCount;
		
		weapon tempWeapon;
		Game game;
		GameManager gameManager;
		
		public weapon(int character, int x, int y) {	
			super(x , y , GameIDs.Staff);
			this.xCoordinate = x;
			this.yCoordinate = y;
			
			yDirectedSpeed = 4;
			if(character == 0 )
			{
				setAttackDamage(WeaponType.STAFF);
			}
			else if(character == 1)
			{
				setAttackDamage(WeaponType.SWORD);
			}
			else
			{
				setAttackDamage(WeaponType.ARROW);
			}
		}


		public void setAttackDamage(WeaponType weapon)
		{
			switch(weapon)
			{
			case STAFF:
					setAttackDamage(70);
					setAmmoCount(20);
					break;
			case SWORD:
				setAttackDamage(100);
					setAmmoCount(15);	
					break;
			case ARROW:
					setAttackDamage(50);
					setAmmoCount(30);
					break;
			default:
					setAttackDamage(0);
					setAmmoCount(0);
					break;
			}
		}


		public int getAttackDamage() {
			return attackDamage;
		}


		public void setAttackDamage(int attackDamage) {
			this.attackDamage = attackDamage;
		}


		public int getAmmoCount() {
			return ammoCount;
		}


		public void setAmmoCount(int ammoCount) {
			this.ammoCount = ammoCount;
		}


		//@Override
		public void tick() {
			this.yCoordinate += -5;
			
			
		}
		


		//weapon is created here
		@Override
		public void render(Graphics graphics) {
                    
                    Graphics2D g2d = (Graphics2D) graphics;
                    BufferedImage imgElf = null;
                    BufferedImage imgHuman = null;
                    BufferedImage imgWizard = null;
                    try {
                         imgWizard = ImageIO.read(new File ("src/BattleMiddleEarth/power.png"));
                     }catch (IOException e){
                    System.out.println("error loading img");
                    }
                    try {
                         imgElf = ImageIO.read(new File ("src/BattleMiddleEarth/Onyx_Arrow.gif"));
                     }catch (IOException e){
                    System.out.println("error loading img");
                    }
                    try {
                         imgHuman = ImageIO.read(new File ("src/BattleMiddleEarth/sword.gif"));
                     }catch (IOException e){
                    System.out.println("error loading img");
                    }
                    if(ChooseCharacter.charID==1)
                    {
                       
                        g2d.drawImage(imgWizard, xCoordinate, yCoordinate, gameManager.game.gamescr);
               
                    }
                    else if(ChooseCharacter.charID==2)
                    {
                       
                        g2d.drawImage(imgElf, xCoordinate, yCoordinate, gameManager.game.gamescr);
               
                    }
                    else
                    {
                        g2d.drawImage(imgHuman, xCoordinate, yCoordinate, gameManager.game.gamescr);
                    }

		}
		//
		public Rectangle getBounds() {
			// TODO Auto-generated method stub
			return new Rectangle(xCoordinate,yCoordinate,10,10);
                        
			//return null;
		}
		
}