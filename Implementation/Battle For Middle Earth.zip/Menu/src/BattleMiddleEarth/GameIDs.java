/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BattleMiddleEarth;

/**
 *
 * @author Arif
 */
public enum GameIDs {
        Wizard(),
        Human(),
        Elf(),
	Player(),
	Enemy(),
	Sword(),
	Staff(),
	Arrow(),
	Enemy2(),
	BossEnemy(),
	powerUpHealth(),
	powerUpArmor(),
	powerUp()
	
}