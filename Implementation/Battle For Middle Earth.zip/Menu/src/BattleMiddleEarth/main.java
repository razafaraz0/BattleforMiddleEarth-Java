/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BattleMiddleEarth;

import static BattleMiddleEarth.MainFrame.main;

/**
 *
 * @author Arif
 */
public class main {
    public static void main(String args[]) {
       java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                main = new MainFrame();
                main.setVisible(true);
                main.setSize(1100,720);
             
            }
        });
       
       while(!GameMap.startGame) {
            System.out.println(GameMap.startGame);
        }
        
        new Game(GameMap.level) ;
       
   
    }
}
