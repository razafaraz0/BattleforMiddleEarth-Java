/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BattleMiddleEarth;

/**
 *
 * @author Arif
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Enemy extends GameObject {


	
	public Enemy( int xCoordinate , int yCoordinate , GameIDs id)
	{
			super(xCoordinate ,yCoordinate , id );
			xDirectedSpeed = 4;
			yDirectedSpeed = 4;
			
	}
	public Rectangle getBounds(){
		return new Rectangle(xCoordinate,yCoordinate,32,32);
	}
	
	public void tick(){

		xCoordinate += xDirectedSpeed;

		//checks if the enemy doesnot go out of bound
		if(xCoordinate <0 )  
		{
			//System.out.println("Less than 0 "+ xCoordinate);
			xDirectedSpeed = -xDirectedSpeed;
		}
		else if (xCoordinate >= Game.WIDTH)
		{
			//System.out.println("More than weight " +xCoordinate);
			xDirectedSpeed = -xDirectedSpeed;
			
			//meaning that after one complete round the players will go one step down
			yCoordinate += 20;  
		}
		//channges the player yDirection so it doesnot go out of the screen
		else if( (yCoordinate < 0 ) || (yCoordinate >= Game.HEIGHT) )
		{
			yDirectedSpeed = -yDirectedSpeed;
			//System.out.println("Within");
		}

	}
	
	
        GameManager temp = new GameManager();
	public void  render(Graphics graphics)
	{       
                Graphics2D g2d = (Graphics2D) graphics;
                BufferedImage imgOrk = null;
                  try{
                    imgOrk = ImageIO.read(new File ("src/BattleMiddleEarth/ORKgif1.gif"));
                }catch (IOException e){
                    System.out.println("error loading img");
                }
                  g2d.drawImage(imgOrk, xCoordinate, yCoordinate, temp.game.gamescr);
                  /*
		graphics.setColor(Color.RED);
		graphics.fillRect(xCoordinate, yCoordinate, 32, 32);*/
	}
}
