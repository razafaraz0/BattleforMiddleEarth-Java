/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BattleMiddleEarth;

/**
 *
 * @author Arif
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
public class Enemy2  extends Enemy
{

	public Enemy2(int xCoordinate, int yCoordinate, GameIDs id) {
		super(xCoordinate, yCoordinate, id);
		xDirectedSpeed = 6;
		yDirectedSpeed = 6;
	}
	
	public void tick(){

		xCoordinate += xDirectedSpeed;
		//yCoordinate += yDirectedSpeed;

		//checks if the enemy doesnot go out of bound
		if(xCoordinate < 0 )  
		{
			//System.out.println("Less than 0 "+ xCoordinate);
			xDirectedSpeed = -xDirectedSpeed;
		}
		else if (xCoordinate >= Game.WIDTH)
		{
			//System.out.println("More than weight " +xCoordinate);
			xDirectedSpeed = -xDirectedSpeed;
			
			//meaning that after one complete round the players will go one step down
		yCoordinate += 20;  
		}
		//channges the player yDirection so it doesnot go out of the screen
		else if( (yCoordinate <= 0 ) || (yCoordinate >= Game.HEIGHT) )
		{
			yDirectedSpeed = -yDirectedSpeed;
			//System.out.println("Within");
		}

	}
        GameManager manager;
	public void  render(Graphics graphics)
	{

		
                
                
                Graphics2D g2d = (Graphics2D) graphics;
                BufferedImage imgOrg = null;
             
                try{
                    imgOrg = ImageIO.read(new File ("src/BattleMiddleEarth/ORKgif1.gif"));
                }catch (IOException e){
                    System.out.println("error loading img");
                }
                
                g2d.drawImage(imgOrg, xCoordinate, yCoordinate, GameManager.game.gamescr);
      
                //g2d.drawImage(imgOrg, xCoordinate, yCoordinate, manager.game.gamescr);
               // rectPlayer.fillRect(new javax.swing.ImageIcon("WIZARDgif.gif"));
                //ImagePattern imagePatternPlayer = new ImagePattern(image1);
                //rectPlayer.setFill(imagePatternPlayer);
		
                
	}
	
	public Rectangle getBounds(){
		return new Rectangle(xCoordinate,yCoordinate,32,32);
	}
	//add get boudn
	
	
	

}