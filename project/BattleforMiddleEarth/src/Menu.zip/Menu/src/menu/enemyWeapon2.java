/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menu;

/**
 *
 * @author Arif
 */
public class enemyWeapon2 extends enemyWeapon {

	public enemyWeapon2(int x, int y, GameIDs id) {
		super(x, y, id);
		
		this.xCoordinate = x;
		this.yCoordinate = y;
		
		yDirectedSpeed = 3;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void tick() {
		// TODO Auto-generated method stub
		this.yCoordinate += 9;
	}

}
